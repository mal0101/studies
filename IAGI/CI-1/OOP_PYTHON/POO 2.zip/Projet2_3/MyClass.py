from gestion.gestion import Student, Employe

s1 = Student(1, "Ali", "Rabat", "IAGI", 1)
s2 = Student(2, "Malak", "Casablanca", "GEM", 2)
e1 = Employe(3, "Khalid", "Tanger", "IBM", 10000)

s1.toString()
s2.toString()
e1.toString()


